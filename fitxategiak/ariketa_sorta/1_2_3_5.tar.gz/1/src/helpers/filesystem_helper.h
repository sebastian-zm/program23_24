#ifndef FILESYSTEM_HELPER_H
#define FILESYSTEM_HELPER_H

#include <stdbool.h>

bool FILESYSTEM_HELPER_get_base_path(char path[], int size);
bool FILESYSTEM_HELPER_cd_base_path(void);

#endif
